myFastConvoution is the entry, and output convoluted signal;
nonUniformSize output the calculated fft for each partitioned h, and store the index and size of each partitioned h; h is partitioned like 128,128,256,256,512,512..etc
myUniformConvolution performs uniform partitioned convolution;